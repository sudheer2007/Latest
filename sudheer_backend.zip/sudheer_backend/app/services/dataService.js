// const fs = require('fs');
// const data = require('../data/loginData.json');

// const fetchData = () => {
//    const res = fs.readFile (data);
//     return (JSON.parse(res));
// }

// module.exports = fetchData;