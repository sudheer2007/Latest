
const databases1= {
    databases : {
        postgres: {
            database: 'test',
            username: 'postgres',
            password: 'password-1',
            host: 'localhost',
            port: '5432',
            schema: 'db',
            dialect: 'postgres',
        }
    }
}

module.exports = databases1;