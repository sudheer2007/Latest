import React, { Component } from 'react';
const About = (props) => {
  return (
    <div>
      <h1>Welcome</h1>
      {/* <a onClick={() => { props.history.push('/home') }}> </a> */}  
    </div>)
}
export default About;